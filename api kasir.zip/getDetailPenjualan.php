<?php 
	header("Content-type: application/json; charset=ISO-8859-1");
	include_once "koneksi.php";
	
	   
	    $penjualan_id =  $_GET['penjualan_id'];
	

		$sql = "SELECT pd.penjualan_detail_id, pd.penjualan_id, br.barang_nama, br.harga, pd.jumlah, (br.harga*pd.jumlah) as total FROM `penjualan_detail` as pd left join barang as br on pd.barang_id=br.barang_id WHERE penjualan_id='$penjualan_id' order by pd.penjualan_detail_id asc";
	//print ($sql);
		$query = mysqli_query($koneksi, $sql);

		$arrBarang = array();
			while ($row = mysqli_fetch_array($query)){
				$arrBarang[] = $row;
				
			}
			
	print json_encode($arrBarang);
	
	mysqli_close($koneksi);
 ?>