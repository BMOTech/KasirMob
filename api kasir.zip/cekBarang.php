<?php 
	header("Content-type: application/json; charset=ISO-8859-1");
	include_once "koneksi.php";
	
	   
	    $barang_id =  $_GET['barang_id'];
	        

		$sql = "SELECT * from barang where barang_id='$barang_id'";
	//print ($sql);
		$query = mysqli_query($koneksi, $sql);
        
		$arrBarang = array();
			while ($row = mysqli_fetch_array($query)){
				$arrBarang[] = $row;
				
			}
			$status=array();
			$status['ada'] = count($arrBarang);
			$status['barang'] = $arrBarang;
			
	print json_encode($status);
	
	mysqli_close($koneksi);
 ?>