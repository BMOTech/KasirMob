<?php
	error_reporting(E_ALL);
	ini_set('display_errors', 1);
	include_once "koneksi.php";
    
    $data = json_decode(file_get_contents("php://input"), true);
    $barang_id = $data['barang_id'];
    $jumlah = $data['jumlah'];
    $penjualan_id = $data['penjualan_id'];
    
    echo "barang ".$barang_id;
    print_r($data);
    $status=array();

	$sql = "insert into penjualan_detail(penjualan_id, barang_id, jumlah) values('$penjualan_id','$barang_id', '$jumlah')";
    echo $sql;
	if (mysqli_query($koneksi, $sql)) {
        $status['sukses']=1;
		$status['penjualan_detail_id']=$koneksi->insert_id;

	} else {
		$status['sukses']=0;
		$status['pesan']=mysqli_error($koneksi);
	}

	mysqli_close($koneksi);
	print json_encode($status);



?>