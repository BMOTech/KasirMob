<script src="https://code.highcharts.com/highcharts.js"></script>

<div id="container" style="width:100%; height:400px;"></div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var myChart = Highcharts.chart('container', {
        chart: {
            type: 'column'
        },
       
        title: {
            text: 'Grafik Penjualan'
        },
        xAxis: {
            categories: ['1 Maret', '2 Maret', '3 Maret']
        },
        yAxis: {
            title: {
                text: 'Item'
            }
        },
        series: [{
            name: 'Nescape',
            data: [5, 7, 8]
        }, {
            name: 'Kitkat',
            data: [4, 8, 9]
        }, {
            name: 'Freshcare',
            data: [1,1, 4]
        }, {
            name: 'Aqua',
            data: [5,6, 8]
        }]
    });
});
</script>