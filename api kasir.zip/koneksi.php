<?php
$server = "rey1024.com";
$user = "u7039630_appkasir";
$pass = "C4sh13r#";
$db = "u7039630_appkasir";

$koneksi = mysqli_connect($server,$user,$pass,$db);
mysqli_set_charset($koneksi,'utf8');
if(mysqli_connect_errno()){
	echo 'Gagal melakukan koneksi ke Database : '.mysqli_connect_error();
}else{
}
?>