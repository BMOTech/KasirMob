<?php
	error_reporting(E_ALL);
	ini_set('display_errors', 1);
	include_once "koneksi.php";
    
    $data = json_decode(file_get_contents("php://input"), true);
    $status_transaksi = $data['status_transaksi'];
    $penjualan_id = $data['penjualan_id'];
    $status=array();

	$sql = "update  penjualan set status_transaksi='$status_transaksi' where penjualan_id='$penjualan_id'";

	if (mysqli_query($koneksi, $sql)) {
        $status['sukses']=1;
        $status['data']=$sql;
	} else {
		$status['sukses']=-1;
		$status['pesan']=mysqli_error($koneksi);
	}

	mysqli_close($koneksi);
	print json_encode($status);



?>